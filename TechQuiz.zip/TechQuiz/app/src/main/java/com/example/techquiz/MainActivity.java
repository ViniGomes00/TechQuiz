package com.example.techquiz;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView totalQuestionsTextView;
    TextView questionTextView;
    Button respA, respB, respC, respD;
    Button submitBtn;

    int score = 0;
    int totalQuestion = QuestionAnswer.question.length;
    int currentQuestionIndex = 0;
    String selectedAnswer = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        totalQuestionsTextView = findViewById(R.id.total_question);
        questionTextView = findViewById(R.id.question);
        respA = findViewById(R.id.resp_A);
        respB = findViewById(R.id.resp_B);
        respC = findViewById(R.id.resp_C);
        respD = findViewById(R.id.resp_D);
        submitBtn = findViewById(R.id.submit_btn);

        respA.setOnClickListener(this);
        respB.setOnClickListener(this);
        respC.setOnClickListener(this);
        respD.setOnClickListener(this);
        submitBtn.setOnClickListener(this);

        totalQuestionsTextView.setText("Questões totais: " + totalQuestion);
        loadNewQuestion();
    }

    @Override
    public void onClick(View view) {
        respA.setBackgroundColor(Color.WHITE);
        respB.setBackgroundColor(Color.WHITE);
        respC.setBackgroundColor(Color.WHITE);
        respD.setBackgroundColor(Color.WHITE);

        Button clickedButton = (Button) view;
        if (clickedButton.getId() == R.id.submit_btn) {

            if (selectedAnswer.equals(QuestionAnswer.correctAnswers[currentQuestionIndex])) {
                score++;
            }
            currentQuestionIndex++;
            loadNewQuestion();

        } else {
            selectedAnswer = clickedButton.getText().toString();
            clickedButton.setBackgroundColor(Color.BLACK);
        }

    }

    void loadNewQuestion() {

        if(currentQuestionIndex == totalQuestion ){
            finishQuiz();
            return;
        }

        questionTextView.setText(QuestionAnswer.question[currentQuestionIndex]);
        respA.setText(QuestionAnswer.choices[currentQuestionIndex][0]);
        respB.setText(QuestionAnswer.choices[currentQuestionIndex][1]);
        respC.setText(QuestionAnswer.choices[currentQuestionIndex][2]);
        respD.setText(QuestionAnswer.choices[currentQuestionIndex][3]);

    }

    //Notificação do quiz onde mostra se o usuário foi aprovado ou reprovado
    void finishQuiz(){
        String passStatus = "";
        if(score > totalQuestion*0.60){
            passStatus = "Aprovado";
        }else{
            passStatus = "Reprovado";
        }

        new AlertDialog.Builder(this)
                .setTitle(passStatus)
                .setMessage("Pontuação "+score+" de "+ totalQuestion)
                .setPositiveButton("Reiniciar", (dialogInterface, i) -> restartQuiz() )
                .setCancelable(false)
                .show();
    }

    //Reiniciar o quiz
    void restartQuiz(){
        score = 0;
        currentQuestionIndex =0;
        loadNewQuestion();
    }
}