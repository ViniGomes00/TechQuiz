package com.example.techquiz;

public class QuestionAnswer {

    //Onde ficam as perguntas
    public static String question[] ={
            "Qual empresa é dona do YouTube?",
            "Qual formato de imagem é conhecido por ser em forma animada?",
            "Qual é a unica opção por não ser um periférico, em termos de computação?",
            "Qual destes é o único dispositivos de saída (dispositivos que exibem dados ao usuário)?",
            "Qual modelo de celular foi responsável pela popularização dos smartphones?",
            "Qual o sistema operacional mais utilizado nos smartphones depois do Android?",
            "Qual sistema operacional é conhecido por ser o mais revolucionário?",
            "Qual correio eletrônico (webmail) é o substituto do Hotmail?",
            "Qual o significado da sigla WWW, em termos de computação?",
            "Qual o sistema operacional desenvolvido pela Google?",
            "Qual o termo correto para o envio em massa de mensagens não autorizadas?",
            "Qual tipo de malware (software malicioso) mais utilizado atualmente?",
            "Qual tipo de malware conhecido por seus anúncios sem a permissão do usuário?",
            "Quantos bits cabem em um byte",
            "Qual componente básico do computador pode ser comparado ao do cérebro humano?"

    };

    //Onde ficam as escolhas
    public static String[][] choices ={
            {"Amazon","Google","Meta","Microsoft"},
            {"GIF","JPG","PDF","ZIP"},
            {"Monitor","Mouse","Processador","Teclado"},
            {"Microfone","Monitor","Scanner","Teclado"},
            {"Apple iPhone","Motorola Atrix","Samsung Galaxy S","Sony Ericsson Xperia"},
            {"iOS","Tizen","Ubuntu Touch","Windows Phone" },
            {"Windows 95","Windows 98","Windows Vista","Windows XP"},
            {"BOL","Gmail","Outlook","Yahoo!"},
            {"Western Washington World","Worldwide Weather","World Wide Web","Width Wickets"},
            {"Android","BlackBerry OS","iOS","Windows Phone"},
            {"Backdoor","Malware","SCAM","SPAM"},
            {"Adware","Cavalo de Troia","Ransomware","Worms"},
            {"Adware","Cavalo de Troia","Ransomware","Worms"},
            {"1 bit","8 bits","10 bits","16 bits"},
            {"Memória RAM","Placa-mãe","Placa de vídeo","Processador"}

    };

    //Onde ficam as respostas corretas
    public static String correctAnswers[] ={
            "Google",
            "GIF",
            "Processador",
            "Monitor",
            "Apple iPhone",
            "iOS",
            "Windows 95",
            "Outlook",
            "World Wide Web",
            "Android",
            "SPAM",
            "Cavalo de Troia",
            "Adware",
            "8 bits",
            "Processador"

    };
}
